from typing import Tuple, List

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

from keras.utils.np_utils import to_categorical
from keras.callbacks import History
from sklearn.model_selection import train_test_split
from skimage.transform import resize

from matplotlib.image import imread, imsave
from matplotlib.patches import Rectangle

from image_augmentation import resize_img

import os
import json
import itertools


data_dir = os.path.join("..", "data")


def read_skin_cancer_data(
    test_split=0.2, seed=None, resize_data=None
) -> Tuple[Tuple[np.ndarray, np.ndarray], Tuple[np.ndarray, np.ndarray]]:
    """
    Reads and cleans skin cancer data from file.
    :param test_split: Percentage of data to be returned for test set.
    :param seed: Random seed for splitting of test and train set.
    :return: (X_train, y_train), (X_test, y_test)
    """
    rgb28df = pd.read_csv(os.path.join(data_dir, "hmnist_28_28_RGB.csv"))
    y_vals = rgb28df["label"].values
    pixel_cols = rgb28df.columns.tolist()[:-1]  # Every column except 'label'
    x_vals = rgb28df[pixel_cols].values / 255
    x_vals = np.reshape(x_vals, (-1, 28, 28, 3))
    if resize_data is not None:
        resize_shape = (
            x_vals.shape[0],
            resize_data[0],
            resize_data[1],
            x_vals.shape[3],
        )
        x_vals = resize(x_vals, resize_shape, preserve_range=True)
    x_train, x_test, y_train, y_test = train_test_split(
        x_vals, y_vals, test_size=test_split, random_state=seed
    )
    y_train = to_categorical(y_train)
    y_test = to_categorical(y_test)
    return (x_train, y_train), (x_test, y_test)


def read_skin_cancer_localization_data(
    test_split=0.2, seed=None, resize_data=None
) -> Tuple[
    Tuple[np.ndarray, np.ndarray, np.ndarray], Tuple[np.ndarray, np.ndarray, np.ndarray]
]:
    """
    Reads and cleans skin cancer localization data from files.
    :param test_split: Percentage of data to be returned for test set.
    :param seed: Random seed for splitting of test and train set.
    :param resize_data: Size to resize images to. None if no resizing required.
    :return: (x_train, bb_train, labels_train), (x_test, bb_test, labels_test)
    """
    metadata_df = pd.read_csv(os.path.join(data_dir, "HAM10000_metadata.csv"))
    class_dict = {}
    for i, lesion_type in enumerate(sorted(metadata_df["dx"].unique())):
        class_dict[lesion_type] = i
    image_dir = os.path.join(data_dir, "resized_images")
    x_vals = []
    y_bb = []
    y_label = []
    for index, row in metadata_df.iterrows():
        file = row["image_id"]
        try:
            image_array = imread(os.path.join(image_dir, file + "rs.jpg"))
            with open(os.path.join(image_dir, file + "rs.json")) as f:
                image_json = json.load(f)
                points = image_json["shapes"][0]["points"]
            if resize_data is not None:
                factor_h = image_array.shape[0] / resize_data[0]
                factor_w = image_array.shape[1] / resize_data[1]
                points[0][0] = int(points[0][0] / factor_w)
                points[1][0] = int(points[1][0] / factor_w)
                points[0][1] = int(points[0][1] / factor_h)
                points[1][1] = int(points[1][1] / factor_h)
                image_array = resize_img(image_array, size=resize_data)
            bb = determine_bounding_box(points[0], points[1])
            x_vals.append(image_array)
            y_label.append(class_dict[row["dx"]])
            y_bb.append(bb)
        except FileNotFoundError:
            continue
    x_vals = np.array(x_vals)
    y_bb = np.array(y_bb)
    y_label = np.array(y_label)

    (
        x_train,
        x_test,
        y_bb_train,
        y_bb_test,
        y_label_train,
        y_label_test,
    ) = train_test_split(x_vals, y_bb, y_label, test_size=test_split, random_state=seed)
    y_label_train = to_categorical(y_label_train)
    y_label_test = to_categorical(y_label_test)

    return (x_train, y_bb_train, y_label_train), (x_test, y_bb_test, y_label_test)


def resize_image_and_json():
    resize_data = (64, 64)
    image_dir = os.path.join(data_dir, "images")
    resized_dir = os.path.join(data_dir, "resized_images")
    metadata_df = pd.read_csv(os.path.join(data_dir, "HAM10000_metadata.csv"))
    for index, row in metadata_df.iterrows():
        file = row["image_id"]
        try:
            with open(os.path.join(image_dir, file + ".json")) as f:
                image_array = imread(os.path.join(image_dir, file + ".jpg"))
                image_json = json.load(f)
                points = image_json["shapes"][0]["points"]
                factor_h = image_array.shape[0] / resize_data[0]
                factor_w = image_array.shape[1] / resize_data[1]
                points[0][0] = int(points[0][0] / factor_w)
                points[1][0] = int(points[1][0] / factor_w)
                points[0][1] = int(points[0][1] / factor_h)
                points[1][1] = int(points[1][1] / factor_h)
                image_array = resize_img(image_array, size=resize_data)
                point_json = {}
                point_json["shapes"] = [{"points": []}]
                point_json["shapes"][0]["points"].append([points[0][0], points[0][1]])
                point_json["shapes"][0]["points"].append([points[1][0], points[1][1]])
                imsave(os.path.join(resized_dir, file + "rs.jpg"), image_array)
                with open(os.path.join(resized_dir, file + "rs.json"), "w+") as fjson:
                    json.dump(point_json, fjson)
        except FileNotFoundError:
            continue
    return


def determine_bounding_box(point1: List[int], point2: List[int]) -> np.ndarray:
    """
    Determine bounding box center, height, and width based on pair of points.
    :param point1: First box point.
    :param point2: Second box point
    :return: Numpy array of shape 1x4 of center_x, center_y, height, and width.
    """
    center_x = int(abs(point1[0] - point2[0]) / 2) + min(point1[0], point2[0])
    center_y = int(abs(point1[1] - point2[1]) / 2) + min(point1[1], point2[1])
    height = int(abs(point1[1] - point2[1]))
    width = int(abs(point1[0] - point2[0]))
    return np.array([center_x, center_y, height, width])


def create_accuracy_plot(
    history: History, title="Model Accuracy", save_file=False, file_prefix="model"
) -> None:
    """
    Creates accuracy plot for model.
    :param history: Keras History object.
    :param title: Plot title
    :param save_file: Whether to save the plot or not.
    :param file_prefix: Prefix for saved file: 'file_prefix'_accuracy.png
    :return:
    """
    plt.plot(history.history["acc"])
    plt.plot(history.history["val_acc"])
    plt.title(title)
    plt.ylabel("Accuracy")
    plt.xlabel("Epoch")
    plt.legend(["Train Acc.", "Validation Acc."], loc="lower right")
    if save_file:
        plt.savefig("{}_accuracy.png".format(file_prefix))
    plt.show()
    return


def create_localization_accuracy_plot(
    history: History,
    title="Localization Model Accuracy",
    save_file=False,
    file_prefix="localization_model",
) -> None:
    """
    Creates accuracy plot for localization model.
    :param history: Keras History object.
    :param title: Plot title
    :param save_file: Whether to save the plot or not.
    :param file_prefix: Prefix for saved file: 'file_prefix'_accuracy.png
    :return:
    """
    plt.plot(history.history["class_output_acc"])
    plt.plot(history.history["box_output_acc"])
    plt.plot(history.history["val_class_output_acc"])
    plt.plot(history.history["val_box_output_acc"])
    plt.title(title)
    plt.ylabel("Accuracy")
    plt.xlabel("Epoch")
    plt.legend(
        ["Class Acc.", "Box Acc.", "Val Class Acc.", "Val Box Acc."], loc="lower right"
    )
    if save_file:
        plt.savefig("{}_accuracy.png".format(file_prefix))
    plt.show()
    return


def create_loss_plot(
    history: History, title="Model Loss", save_file=False, file_prefix="model"
) -> None:
    """
    Creates loss plot for model.
    :param history: Keras History object.
    :param title: Plot title.
    :param save_file: Whether to save the plot or not.
    :param file_prefix: Prefix for saved file: 'file_prefix"_loss.png
    :return:
    """
    plt.plot(history.history["loss"])
    plt.plot(history.history["val_loss"])
    plt.title(title)
    plt.ylabel("Loss")
    plt.xlabel("Epoch")
    plt.legend(["Train Loss", "Validation Loss"], loc="upper right")
    if save_file:
        plt.savefig("{}_loss.png".format(file_prefix))
    plt.show()
    return


def create_localization_loss_plot(
    history: History,
    title="Localization Model Loss",
    save_file=False,
    file_prefix="localization_model",
) -> None:
    """
    Creates loss plot for localization model.
    :param history: Keras History object.
    :param title: Plot title.
    :param save_file: Whether to save the plot or not.
    :param file_prefix: Prefix for saved file: 'file_prefix'_loss.png
    :return:
    """
    plt.plot(history.history["class_output_loss"])
    plt.plot(history.history["box_output_loss"])
    plt.plot(history.history["val_class_output_loss"])
    plt.plot(history.history["val_box_output_loss"])
    plt.title(title)
    plt.ylabel("Loss")
    plt.xlabel("Epoch")
    plt.legend(
        ["Class Loss", "Box Loss", "Val Class Loss", "Val Box Loss"], loc="upper right"
    )
    if save_file:
        plt.savefig("{}_loss.png".format(file_prefix))
    plt.show()
    return


def learning_rate_schedule(index: int, current_lr: float) -> float:
    """
    Function for LearningRateDecay callback.
    :param index: Current epoch index.
    :param current_lr: Current learning rate.
    :return: Updated learning rate.
    """
    if index % 3 == 0:
        return current_lr / 2
    else:
        return current_lr


def draw_bounding_box(img: np.ndarray, bbox: Tuple[int, int, int, int]) -> None:
    """
    Displays a bounding box over the provided image.
    :param img: numpy array of the image to be drawn on.
    :param bbox: Tuple of 4 ints, (center_x, center_y, height, width)
    :return: None
    """
    fig, ax = plt.subplots(1)
    ax.imshow(img)
    top_left_x = int(bbox[0] - bbox[3] / 2)
    top_left_y = int(bbox[1] - bbox[2] / 2)
    rect = Rectangle(
        (top_left_x, top_left_y),
        bbox[3],
        bbox[2],
        linewidth=1,
        edgecolor="r",
        facecolor="none",
    )
    ax.add_patch(rect)
    plt.show()
    return


def plot_confusion_matrix(
    cm, classes, normalize=False, title="Confusion matrix", cmap=plt.cm.Blues
):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """

    if normalize:
        cm = cm.astype("float") / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print("Confusion matrix, without normalization")

    print(cm)

    plt.imshow(cm, interpolation="nearest", cmap=cmap)
    plt.title("Confusion Matrix: " + title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = ".2f" if normalize else "d"
    thresh = cm.max() / 2.0
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(
            j,
            i,
            format(cm[i, j], fmt),
            horizontalalignment="center",
            color="white" if cm[i, j] > thresh else "black",
        )

    plt.ylabel("True label")
    plt.xlabel("Predicted label")
    plt.tight_layout()
    plt.show()

    return