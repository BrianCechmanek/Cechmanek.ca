from typing import Tuple

from scipy.ndimage import rotate
from skimage.filters import gaussian
from skimage.transform import resize
import numpy as np

from keras.preprocessing.image import ImageDataGenerator

import random


def augment_dataset(
    x: np.ndarray,
    rotate=True,
    shift=True,
    flip=True,
    zoom=True,
    shear=True,
    blur=True,
    blur_rate=0.4,
    blur_radii=[1, 2, 3, 4, 5, 6],
) -> Tuple[ImageDataGenerator, np.ndarray]:
    """
    Applys data augmentation of the specified types to the provided dataset.
    :param x: Dataset to augment.
    :param rotate: Whether to apply random rotations.
    :param shift: Whether to apply random shifts.
    :param flip: Whether to apply random flips.
    :param zoom: Whether to apply random zooms.
    :param shear: Whether to apply random shears.
    :param blur: Whether to apply random blurs.
    :param blur_rate: Rate at which to blur images.
    :param blur_radii: Radii to apply blurring at randomly.
    :return: Keras ImageDataGenerator fit to the provided dataset and data options. Additionally blurred data, if any.
    """
    datagen = ImageDataGenerator(
        rotation_range=85 if rotate else 0,
        width_shift_range=0.4 if shift else 0.0,
        height_shift_range=0.4 if shift else 0.0,
        horizontal_flip=flip,
        vertical_flip=flip,
        zoom_range=0.4 if zoom else 0.0,
        shear_range=0.4 if shear else 0.0,
    )
    x_blurred = np.empty((1, x.shape[1], x.shape[2], x.shape[3]), dtype=float)
    if blur:
        for i in range(x.shape[0]):
            if random.random() <= blur_rate:
                radius = random.choice(blur_radii)
                blurred_img = gaussian_blur_img(x[0], blur_radius=radius)
                blurred_img = np.reshape(
                    blurred_img, (1, x.shape[1], x.shape[2], x.shape[3])
                )
                x_blurred = np.append(x_blurred, blurred_img, axis=0)
    x_total = np.concatenate((x, x_blurred), axis=0)
    datagen.fit(x_total)
    return datagen, x_blurred


def rotate_img(image: np.ndarray, angle=0) -> np.ndarray:
    """
    Rotates a single RGB or grayscale image.
    :param image: Image to be rotated.
    :param angle: Angle to rotate by
    :return: Rotated image.
    """
    rotated = rotate(image, angle, reshape=False)
    return rotated


def gaussian_blur_img(image: np.ndarray, blur_radius=0) -> np.ndarray:
    """
    Gaussian blurs image by given radius.
    :param image: Image to be blurred.
    :param blur_radius: Amount of blurring.
    :return: Blurred image.
    """
    return gaussian(image, sigma=blur_radius, preserve_range=True)


def resize_img(image: np.ndarray, size=(32, 32)) -> np.ndarray:
    """
    Resize an image to the given dimensions.
    :param image: HxWxC np array to resize.
    :param size: Dimensions to resize to.
    :return: Resized image.
    """
    resized = resize(image, size, preserve_range=True, anti_aliasing=True)
    return resized.astype(np.uint8)