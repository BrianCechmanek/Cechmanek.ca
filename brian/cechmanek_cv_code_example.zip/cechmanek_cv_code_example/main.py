from keras.models import Model, load_model
from keras import optimizers, callbacks, regularizers
from sklearn.utils.class_weight import compute_class_weight
from sklearn.metrics import confusion_matrix
import os
from typing import Tuple, Iterable
import numpy as np

from utils import *
from image_augmentation import augment_dataset
from nn_models import vgg11, vgg16, vgg16_localization
from nn_models import resnet50, resnet50_localization
from nn_models import custom_architecture1, custom_architecture1_localization

model_dir = os.path.join("..", "saved_models")
print(model_dir)

# def test_vgg11_model():
#     print("Reading skin cancer data...")
#     (x_train, y_train), (x_test, y_test) = read_skin_cancer_data(test_split=0.2, seed=5)
#
#     print("Creating support objects...")
#     early_stopper = callbacks.EarlyStopping(monitor='val_loss', patience=2)
#     lr_plateau = callbacks.ReduceLROnPlateau(monitor="val_acc",
#                                              patience=2,
#                                              verbose=1,
#                                              factor=0.5,
#                                              min_lr=0.000001)
#     adam_optimizer = optimizers.Adam(lr=0.0001)
#     l2_regularizer = regularizers.l2()
#
#     print("Augmenting dataset...")
#     data_generator, _ = augment_dataset(x_train, blur=False)
#
#     print("Creating VGG11 model...")
#     model = vgg11((x_train.shape[1], x_train.shape[2], x_train.shape[3]),
#                   adam_optimizer,
#                   l2_regularizer,
#                   7)
#
#     print("Training model...")
#
#     model, history = train_model(model, x_train, y_train,
#                                  [early_stopper, lr_plateau],
#                                  plot_title="VGG11 Model")
#     return


def test_vgg16_model(optimizer="adam", lr=0.001, class_weight=None):
    print("Reading skin cancer data...")
    (x_train, y_train), (x_test, y_test) = read_skin_cancer_data(test_split=0.2, seed=5)

    print("Creating support objects...")
    early_stopper = callbacks.EarlyStopping(monitor="val_loss", patience=5)
    lr_plateau = callbacks.ReduceLROnPlateau(
        monitor="val_acc", patience=3, verbose=1, factor=0.5, min_lr=0.000001
    )
    model_checkpoint = callbacks.ModelCheckpoint(
        model_dir + "/vgg16_valacc{val_acc:.4f}-epoch{epoch:02d}.h5",
        save_best_only=True,
        verbose=1,
        monitor="val_acc",
    )
    if optimizer == "adam":
        optimizer = optimizers.adam(
            lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, decay=1e-6, amsgrad=False
        )
    elif optimizer == "sgd":
        optimizer = optimizers.sgd(lr=lr, momentum=0.9, nesterov=True, decay=1e-6)
    elif optimizer == "RMSprop":
        optimizer = optimizers.RMSprop(lr=lr, rho=0.9, epsilon=None, decay=1e-6)
    elif optimizer == "Nadam":  # catch case to Nadam
        optimizer = optimizers.Nadam(
            lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, schedule_decay=0.004
        )

    l2_regularizer = regularizers.l2()

    print("Augmenting dataset...")
    data_generator, _ = augment_dataset(x_train, blur=False)

    print("Creating VGG16 model...")
    model = vgg16(
        (x_train.shape[1], x_train.shape[2], x_train.shape[3]),
        optimizer,
        l2_regularizer,
        7,
    )
    model, history = train_model(
        model,
        x_train,
        y_train,
        x_test,
        y_test,  # for confusion_matrix
        [early_stopper, lr_plateau, model_checkpoint],
        class_weight=class_weight,
        plot_title="VGG16 Model",
    )
    print("Training model...")

    return model


def test_resnet50_model(optimizer="Nadam", lr=0.001, class_weight=None):
    print("Reading skin cancer data...")
    (x_train, y_train), (x_test, y_test) = read_skin_cancer_data(
        test_split=0.2, seed=5, resize_data=(32, 32)
    )

    print("Creating support objects...")
    early_stopper = callbacks.EarlyStopping(monitor="val_acc", patience=8)
    lr_plateau = callbacks.ReduceLROnPlateau(
        monitor="val_acc", patience=3, verbose=1, factor=0.5, min_lr=0.000001
    )
    model_checkpoint = callbacks.ModelCheckpoint(
        model_dir + "/resnet50_valacc{val_acc:.4f}-epoch{epoch:02d}.h5",
        save_best_only=True,
        verbose=1,
        monitor="val_acc",
    )

    if optimizer == "adam":
        optimizer = optimizers.adam(
            lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, decay=1e-6, amsgrad=False
        )
    elif optimizer == "sgd":
        optimizer = optimizers.sgd(lr=lr, momentum=0.9, nesterov=True, decay=1e-6)
    elif optimizer == "RMSprop":
        optimizer = optimizers.RMSprop(lr=lr, rho=0.9, epsilon=None, decay=1e-6)
    elif optimizer == "Nadam":  # catch case to Nadam
        optimizer = optimizers.Nadam(
            lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, schedule_decay=0.004
        )

    print("Augmenting dataset...")
    data_generator, _ = augment_dataset(x_train, blur=False)

    print("Creating ResNet50 Model...")
    model = resnet50(
        (x_train.shape[1], x_train.shape[2], x_train.shape[3]),
        optimizer,
        7,
        pretrain=True,
    )

    model, history = train_model(
        model,
        x_train,
        y_train,
        x_test,
        y_test,  # for confusion matrix
        [early_stopper, lr_plateau, model_checkpoint],
        class_weight=class_weight,
        plot_title="ResNet50 Model",
    )
    return model


def test_custom_architecture1_model(optimizer="adam", lr=0.001, class_weight=None):
    print("Reading skin cancer data...")
    (x_train, y_train), (x_test, y_test) = read_skin_cancer_data(
        test_split=0.2, seed=5, resize_data=(64, 64)
    )

    print("Creating support objects...")
    early_stopper = callbacks.EarlyStopping(monitor="val_acc", patience=10)
    lr_plateau = callbacks.ReduceLROnPlateau(
        monitor="val_acc", patience=3, verbose=1, factor=0.5, min_lr=0.000001
    )
    model_checkpoint = callbacks.ModelCheckpoint(
        model_dir + "/custom1_valacc{val_acc:.4f}-epoch{epoch:02d}.h5",
        save_best_only=True,
        verbose=1,
        monitor="val_acc",
    )

    if optimizer == "adam":
        optimizer = optimizers.adam(
            lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, decay=1e-6, amsgrad=False
        )
    elif optimizer == "sgd":
        optimizer = optimizers.sgd(lr=lr, momentum=0.9, nesterov=True, decay=1e-6)
    elif optimizer == "RMSprop":
        optimizer = optimizers.RMSprop(lr=lr, rho=0.9, epsilon=None, decay=1e-6)
    elif optimizer == "Nadam":  # catch case to Nadam
        optimizer = optimizers.Nadam(
            lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, schedule_decay=0.004
        )

    # regularizer = regularizers.l2()

    print("Augmenting dataset...")
    data_generator, _ = augment_dataset(x_train, blur=False)

    print("Creating custom model 1...")
    model = custom_architecture1(
        (x_train.shape[1], x_train.shape[2], x_train.shape[3]),
        optimizer,
        # regularizer,
        7,
    )
    model, history = train_model(
        model,
        x_train,
        y_train,
        x_test,
        y_test,  # for confusion matrix
        [early_stopper, lr_plateau, model_checkpoint],
        class_weight=class_weight,
        plot_title="Custom Architecture Model",
    )
    return model


def test_resnet50_localization_model(optimizer="Nadam", lr=0.0001):
    print("Reading skin cancer data...")
    (x_train, y_bb_train, y_label_train), (
        x_test,
        y_bb_test,
        y_label_test,
    ) = read_skin_cancer_localization_data(test_split=0.2, seed=5, resize_data=(64, 64))
    early_stopper = callbacks.EarlyStopping(monitor="val_loss", patience=7)
    lr_plateau = callbacks.ReduceLROnPlateau(
        monitor="val_loss", patience=3, verbose=1, factor=0.5, min_lr=0.000001
    )
    model_checkpoint = callbacks.ModelCheckpoint(
        model_dir
        + "/resnet50local_valacc{val_class_output_acc:.4f}-epoch{epoch:02d}.hdf5",
        save_best_only=True,
        verbose=1,
        monitor="val_class_output_acc",
    )
    # optimizer = optimizers.Nadam(0.0001)
    if optimizer == "adam":
        optimizer = optimizers.adam(
            lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, decay=1e-6, amsgrad=False
        )
    elif optimizer == "sgd":
        optimizer = optimizers.sgd(lr=lr, momentum=0.9, nesterov=True, decay=1e-6)
    elif optimizer == "RMSprop":
        optimizer = optimizers.RMSprop(lr=lr, rho=0.9, epsilon=None, decay=1e-6)
    elif optimizer == "Nadam":  # catch case to Nadam
        optimizer = optimizers.Nadam(
            lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, schedule_decay=0.004
        )

    print("Creating ResNet50 Localization Model...")
    model = resnet50_localization(x_train.shape[1:], optimizer, 7, pretrain=True)

    print("Training model...")

    model, history = train_localization_model(
        model,
        x_train,
        y_bb_train,
        y_label_train,
        x_test,
        y_label_test,
        [lr_plateau, early_stopper, model_checkpoint],
        plot_title="ResNet50 Localization Model",
    )
    return model


def test_vgg16_localization_model(optimizer="adam", lr=0.001):
    print("Reading skin cancer data...")
    (x_train, y_bb_train, y_label_train), (
        x_test,
        y_bb_test,
        y_label_test,
    ) = read_skin_cancer_localization_data(test_split=0.2, seed=5, resize_data=(64, 64))
    early_stopper = callbacks.EarlyStopping(monitor="val_loss", patience=8)
    lr_plateau = callbacks.ReduceLROnPlateau(
        monitor="val_loss", patience=3, verbose=1, factor=0.5, min_lr=0.000001
    )

    if optimizer == "adam":
        optimizer = optimizers.adam(
            lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, decay=1e-6, amsgrad=False
        )
    elif optimizer == "sgd":
        optimizer = optimizers.sgd(lr=lr, momentum=0.9, nesterov=True, decay=1e-6)
    elif optimizer == "RMSprop":
        optimizer = optimizers.RMSprop(lr=lr, rho=0.9, epsilon=None, decay=1e-6)
    elif optimizer == "Nadam":  # catch case to Nadam
        optimizer = optimizers.Nadam(
            lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, schedule_decay=0.004
        )

    print("Creating VGG16 Localization Model...")
    model = vgg16_localization(x_train.shape[1:], optimizer, 7, pretrain=True)

    print("Training model...")

    model, history = train_localization_model(
        model,
        x_train,
        y_bb_train,
        y_label_train,
        x_test,
        y_label_test,
        [lr_plateau, early_stopper],
        plot_title="VGG16 Localization Model",
    )
    return


def test_custom_architecture1_localization_model(optimizer="Nadam", lr=0.0001):
    print("Reading skin cancer data...")
    (x_train, y_bb_train, y_label_train), (
        x_test,
        y_bb_test,
        y_label_test,
    ) = read_skin_cancer_localization_data(test_split=0.2, seed=5, resize_data=(64, 64))
    early_stopper = callbacks.EarlyStopping(monitor="val_loss", patience=7)
    lr_plateau = callbacks.ReduceLROnPlateau(
        monitor="val_loss", patience=3, verbose=1, factor=0.5, min_lr=0.000001
    )
    model_checkpoint = callbacks.ModelCheckpoint(
        model_dir
        + "/custom1_local_valacc{val_class_output_acc:.4f}-epoch{epoch:02d}.hdf5",
        save_best_only=True,
        verbose=1,
        monitor="val_class_output_acc",
    )
    # optimizer = optimizers.Nadam(0.0001)
    if optimizer == "adam":
        optimizer = optimizers.adam(
            lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, decay=1e-6, amsgrad=False
        )
    elif optimizer == "sgd":
        optimizer = optimizers.sgd(lr=lr, momentum=0.9, nesterov=True, decay=1e-6)
    elif optimizer == "RMSprop":
        optimizer = optimizers.RMSprop(lr=lr, rho=0.9, epsilon=None, decay=1e-6)
    elif optimizer == "Nadam":  # catch case to Nadam
        optimizer = optimizers.Nadam(
            lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, schedule_decay=0.004
        )

    print("Creating custom architecture Localization Model...")
    model = custom_architecture1_localization(x_train.shape[1:], optimizer, 7)

    print("Training model...")

    model, history = train_localization_model(
        model,
        x_train,
        y_bb_train,
        y_label_train,
        x_test,
        y_label_test,
        [lr_plateau, early_stopper, model_checkpoint],
        plot_title="Custom Architecture1 Localization Model",
    )
    return model


def train_model(
    model: Model,
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_test: np.ndarray,
    y_test: np.ndarray,
    model_callbacks: Iterable[callbacks.Callback],
    class_weight: dict,
    plot_title="Model History",
    save_plots=False,
    val_split=0.1,
) -> Tuple[Model, callbacks.History]:
    val_index = int(val_split * len(x_train))
    x_train_split = x_train[-val_index:]
    y_train_split = y_train[-val_index:]
    x_val_split = x_train[:-val_index]
    y_val_split = y_train[:-val_index]
    data_generator, _ = augment_dataset(x_train, blur=False)
    history = model.fit_generator(
        data_generator.flow(x_train_split, y_train_split, batch_size=128),
        steps_per_epoch=len(x_train_split) / 128,
        epochs=100,  # testing for epochs =10
        # class_weight=class_weight,
        callbacks=model_callbacks,
        verbose=1,
        validation_data=(x_val_split, y_val_split),
    )
    create_accuracy_plot(history, plot_title, save_plots)
    create_loss_plot(history, plot_title, save_plots)
    y_pred = model.predict(x_test)
    conf_labels = ["akiec", "bcc", "mel", "df", "nv", "vasc", "bkl"]
    conf_mat = confusion_matrix(y_test.argmax(axis=1), y_pred.argmax(axis=1))
    plot_confusion_matrix(conf_mat, title=plot_title, classes=conf_labels)
    return model, history


def train_localization_model(
    model: Model,
    x_train: np.ndarray,
    y_bb_train: np.ndarray,
    y_class_train: np.ndarray,
    x_test: np.ndarray,
    y_class_test: np.ndarray,
    model_callbacks: Iterable[callbacks.Callback],
    plot_title="Localization Model History",
    save_plots=False,
    val_split=0.1,
) -> Tuple[Model, callbacks.History]:
    history = model.fit(
        x_train,
        {"class_output": y_class_train, "box_output": y_bb_train},
        batch_size=64,
        epochs=100,
        callbacks=model_callbacks,
        verbose=2,
        validation_split=val_split,
    )
    create_localization_accuracy_plot(history, plot_title, save_plots)
    create_localization_loss_plot(history, plot_title, save_plots)

    y_class_pred = model.predict(x_test)[1]
    assert (
        len(y_class_pred[0]) == 7
    )  # not confident how .predict outputs multiclass. makes sure this isnt' bbox
    conf_labels = ["akiec", "bcc", "mel", "df", "bkl", "nv", "vasc"]
    conf_mat = confusion_matrix(
        y_class_test.argmax(axis=1), y_class_pred.argmax(axis=1)
    )
    plot_confusion_matrix(conf_mat, title=plot_title, classes=conf_labels)
    return model, history


if __name__ == "__main__":
    test_custom_architecture1_localization_model()