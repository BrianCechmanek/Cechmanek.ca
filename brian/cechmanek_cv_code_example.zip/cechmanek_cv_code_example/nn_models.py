from keras.models import Sequential, Model
from keras.layers.core import Flatten, Dense, Dropout
from keras.layers.convolutional import Convolution2D, MaxPooling2D, ZeroPadding2D
from keras.layers import BatchNormalization, Activation, Input
from keras.regularizers import l2, Regularizer
from keras.optimizers import Optimizer
from keras.applications.resnet50 import ResNet50

from keras.applications.vgg16 import VGG16
from keras.utils import plot_model

from typing import Tuple, Union


def vgg11(
    input_shape: Tuple[int, int, int],
    optimizer: Union[str, Optimizer],
    regularizer: Union[Regularizer, None],
    num_classes: int,
) -> Sequential:
    model = Sequential()
    model.add(
        Convolution2D(
            64,
            (3, 3),
            input_shape=input_shape,
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))
    model.add(ZeroPadding2D((1, 1)))

    model.add(
        Convolution2D(
            128,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))
    model.add(ZeroPadding2D((1, 1)))

    model.add(
        Convolution2D(
            256,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(
        Convolution2D(
            256,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))
    model.add(ZeroPadding2D((1, 1)))

    model.add(
        Convolution2D(
            512,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(
        Convolution2D(
            512,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))
    model.add(ZeroPadding2D((1, 1)))

    model.add(
        Convolution2D(
            512,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(
        Convolution2D(
            512,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))

    model.add(Flatten())
    model.add(
        Dense(
            4096,
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(
        Dense(
            4096,
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(
        Dense(
            num_classes,
            activation="softmax",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )

    model.compile(
        optimizer=optimizer, loss="categorical_crossentropy", metrics=["accuracy"]
    )
    return model


def vgg16(
    input_shape: Tuple[int, int, int],
    optimizer: Union[str, Optimizer],
    regularizer: Union[Regularizer, None],
    num_classes: int,
) -> Sequential:
    model = Sequential()
    model.add(
        Convolution2D(
            64,
            (3, 3),
            input_shape=input_shape,
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(
        Convolution2D(
            64,
            (3, 3),
            input_shape=input_shape,
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))
    model.add(ZeroPadding2D((1, 1)))

    model.add(
        Convolution2D(
            128,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(
        Convolution2D(
            128,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))
    model.add(ZeroPadding2D((1, 1)))

    model.add(
        Convolution2D(
            256,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(
        Convolution2D(
            256,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(
        Convolution2D(
            256,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))
    model.add(ZeroPadding2D((1, 1)))

    model.add(
        Convolution2D(
            512,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(
        Convolution2D(
            512,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(
        Convolution2D(
            512,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))
    model.add(ZeroPadding2D((1, 1)))

    model.add(
        Convolution2D(
            512,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(
        Convolution2D(
            512,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(ZeroPadding2D((1, 1)))
    model.add(
        Convolution2D(
            512,
            (3, 3),
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))

    model.add(Flatten())
    model.add(
        Dense(
            4096,
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(
        Dense(
            4096,
            activation="relu",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )
    model.add(
        Dense(
            num_classes,
            activation="softmax",
            kernel_regularizer=regularizer,
            bias_regularizer=regularizer,
        )
    )

    model.compile(
        optimizer=optimizer, loss="categorical_crossentropy", metrics=["accuracy"]
    )
    return model


def vgg16_localization(
    input_shape: Tuple[int, int, int],
    optimizer: Optimizer,
    num_classes: int,
    pretrain=False,
) -> Model:
    input = Input(shape=input_shape)
    resnet = VGG16(input_tensor=input, weights=None, include_top=False)
    # print(resnet)
    resnet = Flatten()(resnet.layers[-1].output)
    first_dense = Dense(4096, activation="relu")(resnet)
    box_dense = Dense(4096, activation="relu")(first_dense)
    box_output = Dense(4, activation="relu", name="box_output")(box_dense)

    class_dense = Dense(4096, activation="relu")(first_dense)
    class_output = Dense(num_classes, activation="softmax", name="class_output")(
        class_dense
    )
    model = Model(inputs=input, outputs=[box_output, class_output])
    model.compile(
        optimizer=optimizer,
        loss={
            "class_output": "categorical_crossentropy",
            "box_output": "mean_squared_error",
        },
        loss_weights={"class_output": 1.0, "box_output": 0.1},
        metrics=["accuracy"],
    )
    # plot_model(model, to_file="model.png")
    return model


def resnet50(
    input_shape: Tuple[int, int, int],
    optimizer: Optimizer,
    num_classes: int,
    pretrain=False,
) -> Model:
    if not pretrain:
        model = ResNet50(input_shape=input_shape, weights=None, classes=num_classes)
    else:
        model = Sequential()
        model.add(ResNet50(input_shape=input_shape, include_top=False))
        model.add(Flatten())
        model.add(Dense(num_classes, activation="softmax"))
    model.compile(
        optimizer=optimizer, loss="categorical_crossentropy", metrics=["accuracy"]
    )

    return model


def resnet50_localization(
    input_shape: Tuple[int, int, int],
    optimizer: Optimizer,
    num_classes: int,
    pretrain=False,
) -> Model:
    input = Input(shape=input_shape)
    resnet = ResNet50(
        input_tensor=input, weights="imagenet" if pretrain else None, include_top=False
    )
    resnet = Flatten()(resnet.layers[-1].output)
    first_dense = Dense(4096, activation="relu")(resnet)
    box_dense = Dense(4096, activation="relu")(first_dense)
    box_output = Dense(4, activation="relu", name="box_output")(box_dense)

    class_dense = Dense(4096, activation="relu")(first_dense)
    class_output = Dense(num_classes, activation="softmax", name="class_output")(
        class_dense
    )
    model = Model(inputs=input, outputs=[box_output, class_output])
    model.compile(
        optimizer=optimizer,
        loss={
            "class_output": "categorical_crossentropy",
            "box_output": "mean_squared_error",
        },
        loss_weights={"class_output": 1.0, "box_output": 0.2},
        metrics=["accuracy"],
    )

    return model


def custom_architecture1(
    input_shape: Tuple[int, int, int], optimizer: Optimizer, num_classes: int
) -> Model:
    model = Sequential()
    model.add(
        Convolution2D(64, (3, 3), input_shape=input_shape, activation="relu")
    )  # 64x64
    model.add(BatchNormalization())
    model.add(ZeroPadding2D((1, 1)))
    model.add(
        Convolution2D(64, (3, 3), input_shape=input_shape, activation="relu")
    )  # 64x64
    model.add(ZeroPadding2D((1, 1)))
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))  # 32x32

    model.add(Convolution2D(128, (3, 3), activation="relu", padding="valid"))  # 30x30
    model.add(Convolution2D(128, (3, 3), activation="relu", padding="valid"))  # 28x28
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))  # 14x14

    model.add(Convolution2D(256, (3, 3), activation="relu", padding="valid"))  # 12x12
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))  # 6x6

    model.add(Convolution2D(512, (3, 3), activation="relu", padding="valid"))  # 4x4
    model.add(Convolution2D(512, (3, 3), activation="relu", padding="valid"))  # 2x2
    model.add(MaxPooling2D((2, 2), strides=(2, 2)))  # 1x1

    model.add(Flatten())
    model.add(Dense(4096, activation="relu"))
    model.add(Dense(4096, activation="relu"))
    model.add(Dense(num_classes, activation="softmax"))

    model.compile(
        optimizer=optimizer, loss="categorical_crossentropy", metrics=["accuracy"]
    )
    return model


def custom_architecture1_localization(
    input_shape: Tuple[int, int, int], optimizer: Optimizer, num_classes: int
) -> Model:
    custom = custom_architecture1(
        input_shape=input_shape, optimizer=optimizer, num_classes=num_classes
    )
    input = custom.input
    custom = Flatten()(custom.layers[13].output)
    first_dense = Dense(4096, activation="relu")(custom)
    box_dense = Dense(4096, activation="relu")(first_dense)
    box_output = Dense(4, activation="relu", name="box_output")(box_dense)

    class_dense = Dense(4096, activation="relu")(first_dense)
    class_output = Dense(num_classes, activation="softmax", name="class_output")(
        class_dense
    )
    model = Model(inputs=input, outputs=[box_output, class_output])
    model.compile(
        optimizer=optimizer,
        loss={
            "class_output": "categorical_crossentropy",
            "box_output": "mean_squared_error",
        },
        loss_weights={"class_output": 1.0, "box_output": 0.1},
        metrics=["accuracy"],
    )

    return model
